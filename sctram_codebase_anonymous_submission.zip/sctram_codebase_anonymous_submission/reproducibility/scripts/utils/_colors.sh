#!/bin/bash

YELLOW="\033[1;33m"
RED="\033[1;31m"
BLUE='\033[0;34m'
RESET="\033[0m"
