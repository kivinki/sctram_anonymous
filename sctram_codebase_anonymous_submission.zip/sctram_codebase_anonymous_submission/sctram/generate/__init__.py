"""Generate artificial embedding or retrieve real datasets online."""
