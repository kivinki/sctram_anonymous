"""Generate artificial embedding."""
