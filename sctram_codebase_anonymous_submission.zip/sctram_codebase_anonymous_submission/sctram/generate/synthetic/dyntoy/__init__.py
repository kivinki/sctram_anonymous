#!/usr/bin/env python3

"""Synthetic Data Generation via dyntoy implementation."""
