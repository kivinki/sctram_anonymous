#!/usr/bin/env python3

"""Simple Synthetic Data Generation."""

from sctram.generate.synthetic.simple._adjacency_matrix_generator import AdjacencyMatrixGenerator  # noqa
from sctram.generate.synthetic.simple._centroid_calculator import CentroidCalculator  # noqa
from sctram.generate.synthetic.simple._space_populator import SpacePopulator  # noqa
