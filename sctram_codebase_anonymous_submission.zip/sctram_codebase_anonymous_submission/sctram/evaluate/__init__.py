"""Metrics comparing inferred trajectory with the provided one/ones."""

# TODO: check scib dpt method

# TODO: recalculation of knn etc over and over.. `benchmark` should resolve.
# TODO: the classses should return the calculations to be used as in `benchmark`

# TODO: a module/class to scale the obtained scores. 0 is terrible, 1 is perfect.

# TODO: min total_counts / n-genes for DPT inference method (dependent)

# TODO: adata generation infer takes X by default. indicate it several places, raise warning
