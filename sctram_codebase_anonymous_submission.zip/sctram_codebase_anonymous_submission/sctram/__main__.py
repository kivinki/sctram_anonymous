"""Command-line interface."""

# TODO: edit for giving info


def main() -> None:
    """sctram."""
    pass


if __name__ == "__main__":
    main()
