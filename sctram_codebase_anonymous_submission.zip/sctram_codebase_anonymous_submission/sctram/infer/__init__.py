"""Methods to infer the trajectories from dataset."""

# Gets a n-dimensional numpy array and creates either a 1-d numpy array or 2-d numpy array (adjacency matrix)
