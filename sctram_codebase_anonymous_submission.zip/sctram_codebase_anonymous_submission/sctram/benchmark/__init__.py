"""Functions to compare trajectory conservation metrics."""
