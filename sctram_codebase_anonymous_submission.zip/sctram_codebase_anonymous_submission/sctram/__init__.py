"""Top-level package for sctram."""

# [line removed as part of blind peer review process]
# [line removed as part of blind peer review process]
__version__ = "0.0.1"
