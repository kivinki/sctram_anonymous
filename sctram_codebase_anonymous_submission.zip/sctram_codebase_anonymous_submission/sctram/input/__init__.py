#!/usr/bin/env python3

"""Input and output functions."""

from sctram.input._input_trajectories import InputTrajectories  # noqa
from sctram.input._input_trajectory import InputTrajectory  # noqa
