class DocTest:
    """Test text."""

    def a1(self, x1, x2):
        """Helmhotz.

        Args:
# [line removed as part of blind peer review process]
        """
        pass
        # It is just for making sure the html creator script works
        # Please remove at some point.
