"""Test suite for the sctram package."""
